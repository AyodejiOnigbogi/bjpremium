import { products } from "@/lib/products";
import ProductCard from "@/components/ProductCard";
import Testimonials from "@/components/Testimonials";
import Newsletter from "@/components/Newsletter";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden bg-gradient-to-br from-background via-background to-secondary/20">
        <div className="container grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Hero Content */}
          <div className="space-y-6">
            <div>
              <p className="text-sm font-medium text-primary uppercase tracking-wider mb-3">
                Premium Nigerian Ingredients
              </p>
              <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
                Super Delicious<br />
                <span className="text-primary">Food Items</span>
              </h1>
            </div>
            <p className="text-lg text-muted-foreground max-w-md leading-relaxed">
              Awoof prices. Quality Nigerian ingredients sourced fresh from trusted markets. Fast delivery across Lagos.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-secondary cta-text"
                asChild
              >
                <a href="#products">
                  See Menu
                  <ArrowRight className="w-4 h-4 ml-2" />
                </a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground cta-text"
                asChild
              >
                <a href="https://wa.me/2348147790998" target="_blank" rel="noopener noreferrer">
                  Chat on WhatsApp
                </a>
              </Button>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative h-96 md:h-full">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-3xl" />
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663393027193/Zm27rhXA6dwpo9CNfuLyju/hero-ponmo-showcase-N4dw6J4b8KBHtntv5mpzTu.webp"
              alt="Premium Ponmo"
              className="w-full h-full object-cover rounded-3xl border-2 border-primary/30"
            />
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-20 bg-secondary/10 border-t border-border">
        <div className="container">
          <div className="mb-12">
            <p className="text-sm font-medium text-accent uppercase tracking-wider mb-3">
              Shop by Category
            </p>
            <h2 className="text-4xl font-bold text-foreground mb-4">
              From soups to stews—stock your kitchen with the best Nigerian ingredients.
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Why Us Section */}
      <section id="why-us" className="py-20">
        <div className="container">
          <h2 className="text-4xl font-bold text-foreground mb-12 text-center">
            Why Choose BJ Premium Foods
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">🌾</span>
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">
                Sourced Fresh
              </h3>
              <p className="text-muted-foreground">
                From trusted markets with quality guarantees
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">✨</span>
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">
                Clean & Sand-Free
              </h3>
              <p className="text-muted-foreground">
                Premium quality crayfish & well-dried ponmo
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">⚡</span>
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">
                Fast Delivery
              </h3>
              <p className="text-muted-foreground">
                Delivered in hours across Lagos
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">🏪</span>
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">
                Wholesale & Retail
              </h3>
              <p className="text-muted-foreground">
                Available in any quantity you need
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Order Section */}
      <section id="order" className="py-20 bg-gradient-to-r from-primary to-secondary text-primary-foreground">
        <div className="container text-center">
          <h2 className="text-4xl font-bold mb-6">
            Get Your Ingredients
          </h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Reply in minutes. Delivered in hours. Order now via WhatsApp for the fastest service.
          </p>
          <Button
            size="lg"
            className="bg-primary-foreground text-primary hover:bg-muted cta-text"
            asChild
          >
            <a href="https://wa.me/2348147790998" target="_blank" rel="noopener noreferrer">
              Chat on WhatsApp
              <ArrowRight className="w-4 h-4 ml-2" />
            </a>
          </Button>
        </div>
      </section>

      {/* Testimonials Section */}
      <Testimonials />

      {/* Newsletter Section */}
      <Newsletter />

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="container">
          <h2 className="text-4xl font-bold text-foreground mb-12 text-center">
            Contact Us
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-card p-8 rounded-lg text-center border border-primary/20 hover:border-primary/50 transition-colors">
              <div className="text-4xl mb-4">💬</div>
              <h3 className="text-lg font-bold text-foreground mb-2">WhatsApp</h3>
              <a
                href="https://wa.me/2348147790998"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:text-secondary transition-colors font-medium"
              >
                +234 814 779 0998
              </a>
            </div>

            <div className="bg-card p-8 rounded-lg text-center border border-border">
              <div className="text-4xl mb-4">📍</div>
              <h3 className="text-lg font-bold text-foreground mb-2">Location</h3>
              <p className="text-muted-foreground">
                Lagos, Nigeria
              </p>
            </div>

            <div className="bg-card p-8 rounded-lg text-center border border-border">
              <div className="text-4xl mb-4">⏱️</div>
              <h3 className="text-lg font-bold text-foreground mb-2">Delivery</h3>
              <p className="text-muted-foreground">
                Same-day delivery available
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-secondary text-primary-foreground py-12 border-t border-border">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">BJ Premium Foods</h4>
              <p className="text-sm opacity-80">
                Quality Nigerian ingredients at awoof prices
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Products</h4>
              <ul className="space-y-2 text-sm opacity-80">
                <li><a href="#products" className="hover:opacity-100 transition-opacity">Ponmo</a></li>
                <li><a href="#products" className="hover:opacity-100 transition-opacity">Crayfish</a></li>
                <li><a href="#products" className="hover:opacity-100 transition-opacity">Grounded Pepper</a></li>
                <li><a href="#products" className="hover:opacity-100 transition-opacity">Egusi</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Company</h4>
              <ul className="space-y-2 text-sm opacity-80">
                <li><a href="#why-us" className="hover:opacity-100 transition-opacity">About Us</a></li>
                <li><a href="#contact" className="hover:opacity-100 transition-opacity">Contact</a></li>
                <li><a href="#order" className="hover:opacity-100 transition-opacity">Order</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Connect</h4>
              <ul className="space-y-2 text-sm opacity-80">
                <li><a href="https://wa.me/2348147790998" target="_blank" rel="noopener noreferrer" className="hover:opacity-100 transition-opacity">WhatsApp</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-background/20 pt-8 text-center text-sm opacity-80">
            <p>&copy; 2026 BJ Premium Foods. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
