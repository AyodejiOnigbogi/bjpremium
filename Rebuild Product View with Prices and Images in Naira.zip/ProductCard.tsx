import { Link } from "wouter";
import { Product } from "@/lib/products";
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <Link href={`/product/${product.slug}`}>
      <a className="group">
        <div className="bg-card rounded-lg overflow-hidden hover:shadow-2xl hover:shadow-primary/20 transition-all duration-300 h-full flex flex-col border border-primary/10 hover:border-primary/40">
          {/* Image Container */}
          <div className="relative h-64 overflow-hidden bg-muted">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </div>

          {/* Content */}
          <div className="flex-1 p-6 flex flex-col justify-between">
            <div>
              <p className="text-xs font-medium text-accent uppercase tracking-wider mb-2">
                {product.category}
              </p>
              <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                {product.name}
              </h3>
              <p className="text-sm text-muted-foreground line-clamp-2">
                {product.description}
              </p>
            </div>

            {/* Price and CTA */}
            <div className="mt-4 pt-4 border-t border-primary/20">
              <p className="text-sm text-muted-foreground mb-3">
                From <span className="font-bold text-primary text-lg">₦{product.startingPrice.toLocaleString()}</span>
              </p>
              <Button
                variant="outline"
                className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-all cta-text"
              >
                View Details
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        </div>
      </a>
    </Link>
  );
}
