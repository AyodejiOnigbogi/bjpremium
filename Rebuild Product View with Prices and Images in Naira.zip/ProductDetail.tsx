import { useParams, Link } from "wouter";
import { getProductBySlug } from "@/lib/products";
import { Button } from "@/components/ui/button";
import { ChevronLeft, Check } from "lucide-react";
import { useState } from "react";

export default function ProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const product = getProductBySlug(slug || "");
  const [selectedVariant, setSelectedVariant] = useState(product?.variants[0]);

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h1 className="text-3xl font-bold text-foreground mb-4">Product Not Found</h1>
        <Link href="/">
          <a className="text-primary hover:text-secondary transition-colors">
            ← Back to Products
          </a>
        </Link>
      </div>
    );
  }

  const handleWhatsAppOrder = () => {
    const message = `Hi, I'm interested in ordering ${product.name} - ${selectedVariant?.quantity} for ₦${selectedVariant?.price.toLocaleString()}`;
    const whatsappUrl = `https://wa.me/2348147790998?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Breadcrumb */}
      <div className="container py-6">
        <Link href="/">
          <a className="inline-flex items-center gap-2 text-primary hover:text-secondary transition-colors mb-8">
            <ChevronLeft className="w-4 h-4" />
            Back to Products
          </a>
        </Link>
      </div>

      {/* Product Section */}
      <div className="container pb-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Image */}
          <div className="flex items-center justify-center">
            <div className="relative w-full aspect-square rounded-lg overflow-hidden bg-muted">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Details */}
          <div className="flex flex-col justify-center">
            <p className="text-sm font-medium text-accent uppercase tracking-wider mb-3">
              {product.category}
            </p>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              {product.name}
            </h1>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              {product.description}
            </p>

            {/* Features */}
            {product.features && product.features.length > 0 && (
              <div className="mb-8 pb-8 border-b border-border">
                <h3 className="text-sm font-semibold text-foreground mb-4 uppercase tracking-wider">
                  Key Features
                </h3>
                <ul className="space-y-3">
                  {product.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-3">
                      <Check className="w-5 h-5 text-primary flex-shrink-0" />
                      <span className="text-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Pricing Variants */}
            <div className="mb-8">
              <h3 className="text-sm font-semibold text-foreground mb-4 uppercase tracking-wider">
                Select Size
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {product.variants.map((variant) => (
                  <button
                    key={variant.id}
                    onClick={() => setSelectedVariant(variant)}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      selectedVariant?.id === variant.id
                        ? "border-primary bg-primary/10"
                        : "border-primary/20 hover:border-primary/50"
                    }`}
                  >
                    <p className="font-semibold text-foreground">{variant.quantity}</p>
                    <p className="text-sm text-muted-foreground">{variant.description}</p>
                    <p className="text-lg font-bold text-primary mt-2">
                      ₦{variant.price.toLocaleString()}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="space-y-3">
              <Button
                onClick={handleWhatsAppOrder}
                className="w-full bg-primary text-primary-foreground hover:bg-secondary py-6 text-lg cta-text"
              >
                Order via WhatsApp - ₦{selectedVariant?.price.toLocaleString()}
              </Button>
              <p className="text-xs text-center text-muted-foreground">
                Fast delivery across Lagos • Wholesale & retail available
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Related Products Section */}
      <div className="bg-muted/30 py-16">
        <div className="container">
          <h2 className="text-3xl font-bold text-foreground mb-8">Why Choose BJ Premium?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-card p-6 rounded-lg border border-primary/20">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">✓</span>
              </div>
              <h3 className="font-bold text-foreground mb-2">Sourced Fresh</h3>
              <p className="text-sm text-muted-foreground">
                From trusted markets with quality guarantees
              </p>
            </div>
            <div className="bg-card p-6 rounded-lg border border-primary/20">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">⚡</span>
              </div>
              <h3 className="font-bold text-foreground mb-2">Fast Delivery</h3>
              <p className="text-sm text-muted-foreground">
                Delivered in hours across Lagos
              </p>
            </div>
            <div className="bg-card p-6 rounded-lg border border-primary/20">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">🏪</span>
              </div>
              <h3 className="font-bold text-foreground mb-2">Wholesale & Retail</h3>
              <p className="text-sm text-muted-foreground">
                Available in any quantity you need
              </p>
            </div>
            <div className="bg-card p-6 rounded-lg border border-primary/20">
              <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                <span className="text-2xl">🎯</span>
              </div>
              <h3 className="font-bold text-foreground mb-2">Premium Quality</h3>
              <p className="text-sm text-muted-foreground">
                Clean, sand-free, and authentic ingredients
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
