export interface ProductVariant {
  id: string;
  quantity: string;
  price: number; // in Naira
  description?: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  category: string;
  description: string;
  image: string;
  startingPrice: number;
  variants: ProductVariant[];
  features?: string[];
}

export const products: Product[] = [
  {
    id: "ponmo",
    name: "Dried Ponmo",
    slug: "dried-ponmo",
    category: "Proteins",
    description: "Premium quality dried cow skin (Ponmo), sourced from trusted markets. Perfect for soups and stews. Clean, sand-free, and well-dried for authentic Nigerian cuisine.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663393027193/Zm27rhXA6dwpo9CNfuLyju/hero-ponmo-showcase-N4dw6J4b8KBHtntv5mpzTu.webp",
    startingPrice: 1000,
    variants: [
      {
        id: "ponmo-3",
        quantity: "3 pieces",
        price: 1000,
        description: "Perfect for small to medium soups"
      },
      {
        id: "ponmo-6",
        quantity: "6 pieces",
        price: 1900,
        description: "Great for family meals"
      },
      {
        id: "ponmo-12",
        quantity: "12 pieces",
        price: 3800,
        description: "Bulk option for large gatherings"
      }
    ],
    features: ["Sand-free", "Well-dried", "Premium quality", "Authentic taste"]
  },
  {
    id: "crayfish",
    name: "Crayfish",
    slug: "crayfish",
    category: "Seasonings",
    description: "Premium Nigerian crayfish, clean and ready to use. Adds authentic umami flavor to soups, stews, and sauces. Sourced fresh from trusted markets.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663393027193/Zm27rhXA6dwpo9CNfuLyju/crayfish-product-EkHPHpW6WyYco57qJ38iwk.webp",
    startingPrice: 200,
    variants: [
      {
        id: "crayfish-1",
        quantity: "1 Sachet",
        price: 200,
        description: "Single serving size"
      },
      {
        id: "crayfish-3",
        quantity: "3 Sachets",
        price: 600,
        description: "Perfect for regular cooking"
      },
      {
        id: "crayfish-12",
        quantity: "12 Sachets",
        price: 2400,
        description: "Wholesale option"
      }
    ],
    features: ["Clean", "Fresh", "Premium quality", "Authentic flavor"]
  },
  {
    id: "grounded-pepper",
    name: "Grounded Pepper",
    slug: "grounded-pepper",
    category: "Seasonings",
    description: "Freshly grounded Nigerian red pepper. Adds vibrant color and authentic spice to your dishes. Perfect for soups, stews, and traditional Nigerian recipes.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663393027193/Zm27rhXA6dwpo9CNfuLyju/grounded-pepper-sachet-nwUQeFKKfEZKwPrz4bJ6qW.webp",
    startingPrice: 200,
    variants: [
      {
        id: "pepper-1",
        quantity: "1 Sachet",
        price: 200,
        description: "Single serving size"
      },
      {
        id: "pepper-3",
        quantity: "3 Sachets",
        price: 600,
        description: "Perfect for regular cooking"
      },
      {
        id: "pepper-12",
        quantity: "12 Sachets",
        price: 2400,
        description: "Wholesale option"
      }
    ],
    features: ["Freshly grounded", "Vibrant color", "Authentic spice", "Premium quality"]
  },
  {
    id: "egusi",
    name: "Egusi",
    slug: "egusi",
    category: "Seasonings",
    description: "Premium Nigerian Egusi (melon seeds). Essential ingredient for authentic Egusi soup. Whole seeds for maximum freshness and flavor.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663393027193/Zm27rhXA6dwpo9CNfuLyju/egusi-seeds-2vcB9MTVZiLePAwJSpvJCB.webp",
    startingPrice: 400,
    variants: [
      {
        id: "egusi-cup",
        quantity: "Per Cup",
        price: 400,
        description: "Standard measurement for recipes"
      }
    ],
    features: ["Whole seeds", "Premium quality", "Fresh", "Authentic taste"]
  }
];

export function getProductBySlug(slug: string): Product | undefined {
  return products.find(p => p.slug === slug);
}

export function getProductsByCategory(category: string): Product[] {
  return products.filter(p => p.category === category);
}

export const categories = ["Proteins", "Seasonings"];
