# Reference Website Analysis: BJ Premium Foods

## Design & Layout
- **Color Palette**: Deep purple background with yellow/gold accents for buttons and highlights.
- **Typography**: Clean, modern sans-serif fonts.
- **Header**: Logo (Premium Foods), Navigation (Products, Why Us, Order, Contact), Cart icon, and "ORDER ON WHATSAPP" button.
- **Hero Section**: "Super Delicious FOOD ITEMS" with circular product images.
- **Product Section**: "Shop by Category" with product cards. Each card has:
  - Circular product image.
  - Product name.
  - "From ₦[Price]" text.
  - "View >" link.
- **Features Section**: "Sourced fresh from trusted markets", "Clean, sand-free crayfish & well-dried ponmo", "Fast delivery across Lagos", "Wholesale & retail available".
- **Order Section**: "Get Your Ingredients" with a "Chat on WhatsApp" button and a contact form (Name, Phone, Product Select, Quantity).
- **Footer**: Navigation links and social media icons.

## Products & Pricing (to be updated)
- **Dried Ponmo**: 3 pieces - 1000, 6 pieces - 1900, 12 pieces - 3800
- **Crayfish**: 1 Sachet - 200, 3 Sachet - 600, 12 Sachet - 2400
- **Grounded Pepper**: 1 Sachet - 200, 3 Sachet - 600, 12 Sachet - 2400
- **Egusi**: Per cup - 400
- **Stockfish**: (Keep from reference if no new price provided)
- **Ogbono**: (Keep from reference if no new price provided)

## Functionality
- "View" links should lead to product detail pages with images and specific pricing.
- WhatsApp integration for ordering.
- Simple contact form.
