# Vercel Environment Variables Setup Guide

## Step 1: Access Your Vercel Project Dashboard

1. Go to [vercel.com](https://vercel.com) and log in with your account
2. Click on your **BJ-premium-foods** project from the dashboard
3. You should see your project name at the top

## Step 2: Navigate to Environment Variables

1. In your project, click the **Settings** tab at the top
2. On the left sidebar, click **Environment Variables**
3. You'll see a form to add new environment variables

## Step 3: Add Analytics Environment Variables

### For VITE_ANALYTICS_ENDPOINT:
1. In the "Name" field, enter: `VITE_ANALYTICS_ENDPOINT`
2. In the "Value" field, enter your Umami analytics endpoint (e.g., `https://analytics.example.com`)
   - If you don't have Umami set up yet, you can skip this or use a placeholder
3. Select which environments this applies to: **Production**, **Preview**, **Development**
4. Click **Add**

### For VITE_ANALYTICS_WEBSITE_ID:
1. In the "Name" field, enter: `VITE_ANALYTICS_WEBSITE_ID`
2. In the "Value" field, enter your Umami website ID (e.g., `abc123def456`)
   - You can find this in your Umami dashboard under Settings
3. Select which environments this applies to: **Production**, **Preview**, **Development**
4. Click **Add**

## Step 4: Redeploy Your Project

1. After adding the environment variables, go to the **Deployments** tab
2. Find your latest deployment
3. Click the **...** (three dots) menu
4. Select **Redeploy**
5. Wait for the deployment to complete

## Step 5: Verify the Setup

1. Once redeployed, visit your live website
2. Open Developer Tools (F12 or right-click → Inspect)
3. Go to the **Network** tab
4. Look for requests to your analytics endpoint to confirm it's working

## Alternative: Using Umami Analytics (Free)

If you don't have analytics set up yet, here's how to use Umami (a free, privacy-friendly alternative):

1. Go to [umami.is](https://umami.is)
2. Sign up for a free account
3. Create a new website and get your Website ID
4. Deploy Umami or use their cloud service
5. Use the Umami endpoint and Website ID in the environment variables above

## Troubleshooting

- **Variables not showing up?** Make sure to redeploy after adding them
- **Analytics not tracking?** Check the browser console for errors (F12 → Console)
- **Still seeing warnings?** Clear your browser cache and hard refresh (Ctrl+Shift+R)

---

**Need help?** Contact Vercel support or check their [documentation](https://vercel.com/docs/projects/environment-variables)
