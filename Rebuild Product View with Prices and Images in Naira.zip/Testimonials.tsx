import { Star } from 'lucide-react';

interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  rating: number;
  avatar?: string;
}

const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Chioma Okafor',
    role: 'Home Chef',
    content: 'The quality of BJ Premium Foods is unmatched! My ponmo is always fresh and sand-free. I recommend them to all my friends.',
    rating: 5,
  },
  {
    id: '2',
    name: 'Tunde Adeyemi',
    role: 'Restaurant Owner',
    content: 'Fast delivery, excellent quality, and competitive prices. BJ Premium Foods is my go-to supplier for all my ingredients.',
    rating: 5,
  },
  {
    id: '3',
    name: 'Zainab Hassan',
    role: 'Food Blogger',
    content: 'The grounded pepper adds authentic flavor to my dishes. Every product I\'ve tried from BJ Premium is top-notch!',
    rating: 5,
  },
  {
    id: '4',
    name: 'Emeka Nwosu',
    role: 'Caterer',
    content: 'Wholesale prices are amazing! I can bulk order without breaking the bank. Highly recommended for business owners.',
    rating: 5,
  },
];

export default function Testimonials() {
  return (
    <section className="py-16 bg-background">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            What Our Customers Say
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Join thousands of satisfied customers who trust BJ Premium Foods for their authentic Nigerian ingredients
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="bg-card border border-primary/20 rounded-lg p-6 hover:border-primary/50 transition-colors"
            >
              {/* Rating Stars */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star
                    key={i}
                    size={16}
                    className="fill-primary text-primary"
                  />
                ))}
              </div>

              {/* Testimonial Content */}
              <p className="text-foreground text-sm mb-4 line-clamp-4">
                "{testimonial.content}"
              </p>

              {/* Customer Info */}
              <div className="border-t border-primary/10 pt-4">
                <p className="font-semibold text-foreground text-sm">
                  {testimonial.name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {testimonial.role}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-4">
            Ready to experience premium Nigerian ingredients?
          </p>
          <a
            href="https://wa.me/2348147790998"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-primary text-primary-foreground px-8 py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors"
          >
            Order Now on WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}
