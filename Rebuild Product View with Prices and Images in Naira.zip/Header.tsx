import { ShoppingCart, Menu, X } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const LOGO_URL = "https://private-us-east-1.manuscdn.com/user_upload_by_module/session_file/310519663393027193/FFiIraDscBzjyZgQ.jpg?Expires=1803904506&Signature=Z4N3BFwFjSLFp8JRbcGo0jZ9hPn~gYcyMLKjwrq50IqYHN5fkNdAqpI1VFuQLFzUtRZSi-m4ROqKFXl879w-xm~KKwHGBZI-kjJ~LfBUM0MBcK~WyxP1T4stzI0kog2BgXtAr5IAMN~cWtg7KOXCwRuo7zN0Iw0Rt30inE6xiDx6ZXUdDpY3qeF5tCiY8xBCYfzzQgFSaRPMGMVdT9otj4VSTntMR9SDX9~jYN44OyuIpSMAXFamruSwvEciBAaCO167g5yV1g49pIihN-XcdB1FyhZm8geczekOyK4Lo2pZyTwDgfUrqbDDK~ysstE-P-OX1cmHbbKiDIfjfZOzDg__&Key-Pair-Id=K2HSFNDJXOU9YS";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-background border-b border-border">
      <div className="container py-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/">
          <a className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <img 
              src={LOGO_URL}
              alt="BJ Premium Foods" 
              className="w-14 h-14 object-contain"
            />
          </a>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <Link href="/">
            <a className="text-foreground hover:text-primary transition-colors font-medium">
              Products
            </a>
          </Link>
          <a href="#why-us" className="text-foreground hover:text-primary transition-colors font-medium">
            Why Us
          </a>
          <a href="#order" className="text-foreground hover:text-primary transition-colors font-medium">
            Order
          </a>
          <a href="#contact" className="text-foreground hover:text-primary transition-colors font-medium">
            Contact
          </a>
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="sm"
            className="hidden sm:flex gap-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground cta-text"
            asChild
          >
            <a href="https://wa.me/2348147790998" target="_blank" rel="noopener noreferrer">
              <span>ORDER ON WHATSAPP</span>
            </a>
          </Button>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 hover:bg-secondary rounded-lg transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6 text-foreground" />
            ) : (
              <Menu className="w-6 h-6 text-foreground" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-border bg-background">
          <nav className="container py-4 flex flex-col gap-4">
            <Link href="/">
              <a className="text-foreground hover:text-primary transition-colors font-medium">
                Products
              </a>
            </Link>
            <a href="#why-us" className="text-foreground hover:text-primary transition-colors font-medium">
              Why Us
            </a>
            <a href="#order" className="text-foreground hover:text-primary transition-colors font-medium">
              Order
            </a>
            <a href="#contact" className="text-foreground hover:text-primary transition-colors font-medium">
              Contact
            </a>
            <Button
              variant="default"
              className="w-full bg-primary text-primary-foreground hover:bg-secondary cta-text mt-2"
              asChild
            >
              <a href="https://wa.me/2348147790998" target="_blank" rel="noopener noreferrer">
                ORDER ON WHATSAPP
              </a>
            </Button>
          </nav>
        </div>
      )}
    </header>
  );
}
